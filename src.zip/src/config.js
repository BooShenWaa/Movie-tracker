export const config = {
  api_key: "api_key=e618217621b3302dcf9198b0685a1ae1",
  FEATURED_API:
    "https://api.themoviedb.org/3/discover/movie?sort_by?popularity.desc&api_key=e618217621b3302dcf9198b0685a1ae1&page=1",

  SEARCH_API:
    "https://api.themoviedb.org/3/search/movie?&api_key=e618217621b3302dcf9198b0685a1ae1&query=",
};
