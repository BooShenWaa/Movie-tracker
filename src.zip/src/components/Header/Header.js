import React, { useState, useContext } from "react";
import { NavLink } from "react-router-dom";
import SearchIcon from "@material-ui/icons/Search";
import { MoviesContext } from "../../context/MoviesContext";
import { config } from "../../config";

function Header() {
  const [searchTerm, setSearchTerm] = useState("");
  const { movies, setMovies, fetchSearch } = useContext(MoviesContext);

  // const SEARCH_API = config.SEARCH_API;

  const submitHandler = (e) => {
    e.preventDefault();
    fetchSearch(searchTerm);
    // console.log(searchTerm);
  };

  const onChangeHandler = (e) => {
    setSearchTerm(e.target.value);
  };

  return (
    <div className="header">
      <nav className="header-left">
        <NavLink to="/">
          <h3>Search</h3>
        </NavLink>
        <NavLink to="/">
          <h3>My List</h3>
        </NavLink>
      </nav>

      <div className="header-center ">
        <h1 className="page-logo"> My Movie Blog </h1>
      </div>
      <div className="header-right">
        <form onSubmit={submitHandler}>
          <input
            type="text"
            className="search"
            placeholder="Search..."
            value={searchTerm}
            onChange={onChangeHandler}
          />
        </form>

        <SearchIcon />
      </div>
    </div>
  );
}

export default Header;
