import React, { useContext } from "react";

const IMG_API = "https://image.tmdb.org/t/p/w1280";

function Movie({ title, pic, overview, rating }) {
  return (
    <div className="movie">
      <img src={IMG_API + pic} alt={title} />
      <div className="movie-info">
        <h3>{title}</h3>
        <span>{rating}</span>
      </div>
      <div className="movie-overview">
        <h3>Overview:</h3>
        <p>{overview}</p>
      </div>
    </div>
  );
}

export default Movie;
