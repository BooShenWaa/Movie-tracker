import React, { createContext, useState } from "react";
import { config } from "./../config";

export const MoviesContext = createContext({
  fetchFeatured: () => [],
  fetchSearch: () => [],
});

export const MoviesProvider = (props) => {
  const [movies, setMovies] = useState([]);

  const FEATURED_API = config.FEATURED_API;
  // "https://api.themoviedb.org/3/movie/550?api_key=e618217621b3302dcf9198b0685a1ae1";
  // "https://api.themoviedb.org/3/discover/movie?sort_by?popularity.desc&api_key=e618217621b3302dcf9198b0685a1ae1&page=1";

  const SEARCH_API = config.SEARCH_API;

  const fetchFeatured = async () => {
    const response = await fetch(FEATURED_API);
    const data = await response.json();
    setMovies(data.results);
    console.log(data.results);
  };

  const fetchSearch = async (term) => {
    const response = await fetch(SEARCH_API + term);
    const data = await response.json();
    setMovies(data.results);
    console.log(data.results);
  };

  return (
    <MoviesContext.Provider value={{ fetchFeatured, movies }}>
      {props.children}
    </MoviesContext.Provider>
  );
};
